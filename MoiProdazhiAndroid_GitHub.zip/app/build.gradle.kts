plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.moiprodazhi"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.moiprodazhi"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
